var searchData=
[
  ['sculptor',['Sculptor',['../class_sculptor.html#af14e9eb97721c3bda79bf4655312a4b2',1,'Sculptor']]],
  ['setcolor',['setColor',['../class_sculptor.html#a4e53f85ee03b729efafa985f72563c4b',1,'Sculptor']]]
];
