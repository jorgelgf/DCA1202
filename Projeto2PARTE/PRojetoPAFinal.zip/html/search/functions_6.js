var searchData=
[
  ['writeoff',['writeOFF',['../class_sculptor.html#a45332b63a1b239a35d634eba60319127',1,'Sculptor']]],
  ['writevect',['writeVECT',['../class_sculptor.html#ad340774fb9160b46e215e42f6e76f37b',1,'Sculptor']]]
];
