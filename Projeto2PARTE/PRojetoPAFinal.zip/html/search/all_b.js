var searchData=
[
  ['sculptor',['Sculptor',['../class_sculptor.html',1,'Sculptor'],['../class_sculptor.html#af14e9eb97721c3bda79bf4655312a4b2',1,'Sculptor::Sculptor()']]],
  ['sculptor_2eh',['sculptor.h',['../sculptor_8h.html',1,'']]],
  ['scultptor_2ecpp',['scultptor.cpp',['../scultptor_8cpp.html',1,'']]],
  ['setcolor',['setColor',['../class_sculptor.html#a4e53f85ee03b729efafa985f72563c4b',1,'Sculptor']]]
];
