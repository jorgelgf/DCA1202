var searchData=
[
  ['figurageometrica',['FiguraGeometrica',['../class_figura_geometrica.html',1,'FiguraGeometrica'],['../class_figura_geometrica.html#a81d7c7efaea511e60a15f5a363138dd9',1,'FiguraGeometrica::FiguraGeometrica()']]],
  ['figurageometrica_2ecpp',['figurageometrica.cpp',['../figurageometrica_8cpp.html',1,'']]],
  ['figurageometrica_2eh',['figurageometrica.h',['../figurageometrica_8h.html',1,'']]]
];
