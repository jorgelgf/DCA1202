var searchData=
[
  ['a',['a',['../structvoxel.html#a802812bf978ffe3609ecdcb84b8b2a55',1,'voxel::a()'],['../class_sculptor.html#a6fd0157dcf17582f0edd5fddf157604e',1,'Sculptor::a()']]]
];
