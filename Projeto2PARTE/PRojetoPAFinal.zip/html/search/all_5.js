var searchData=
[
  ['g',['g',['../structvoxel.html#affdd4dd79bf2df4f606643d14b533236',1,'voxel::g()'],['../class_sculptor.html#a208c06af69a81a1568df4493868816f1',1,'Sculptor::g()']]]
];
