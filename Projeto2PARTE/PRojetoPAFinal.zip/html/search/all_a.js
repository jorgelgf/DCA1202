var searchData=
[
  ['r',['r',['../structvoxel.html#a506f9bce1044eb74f980b7e13b0b94f8',1,'voxel::r()'],['../class_sculptor.html#a3f5d2ec3b66d645019b8d81c810a1cd8',1,'Sculptor::r()']]]
];
