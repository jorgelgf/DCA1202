var searchData=
[
  ['nx',['nx',['../class_sculptor.html#ad1e32f9042538419a3bc7b376f7813b8',1,'Sculptor']]],
  ['ny',['ny',['../class_sculptor.html#a1ce2ff97ec94927928ab3f5ec4ba6761',1,'Sculptor']]],
  ['nz',['nz',['../class_sculptor.html#a33204e7df26a7ee4c7192381a24335d3',1,'Sculptor']]]
];
