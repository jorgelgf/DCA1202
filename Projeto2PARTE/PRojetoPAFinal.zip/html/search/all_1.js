var searchData=
[
  ['b',['b',['../structvoxel.html#acb9686af1a3176320c0837d74702f89d',1,'voxel::b()'],['../class_sculptor.html#a7aafd7305ea634252d8288b60536cd96',1,'Sculptor::b()']]]
];
